

CKEDITOR.replace( 'content' );